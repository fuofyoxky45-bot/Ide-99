"use client";

import { useState, useEffect, useRef, useCallback } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────
const MONACO_CDN = "https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.44.0/min/vs";

const DEFAULT_FILES: Record<string, { content: string; language: string }> = {
  "index.html": {
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My App</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <div class="container">
    <h1>Hello, World! 👋</h1>
    <p>Edit this file to get started.</p>
    <button onclick="greet()">Click me</button>
  </div>
  <script src="app.js"></script>
</body>
</html>`,
    language: "html",
  },
  "style.css": {
    content: `* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.container {
  background: white;
  padding: 2rem 3rem;
  border-radius: 16px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
  text-align: center;
}

h1 {
  font-size: 2.5rem;
  color: #333;
  margin-bottom: 0.5rem;
}

p {
  color: #666;
  margin-bottom: 1.5rem;
}

button {
  background: #667eea;
  color: white;
  border: none;
  padding: 0.75rem 2rem;
  border-radius: 8px;
  font-size: 1rem;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
}

button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(102,126,234,0.5);
}`,
    language: "css",
  },
  "app.js": {
    content: `function greet() {
  const names = ['Developer', 'Coder', 'Creator', 'Builder'];
  const name = names[Math.floor(Math.random() * names.length)];
  alert(\`Hello, \${name}! 🚀\`);
}

console.log('App loaded successfully!');`,
    language: "javascript",
  },
  "notes.py": {
    content: `# Python Example
def fibonacci(n):
    """Generate Fibonacci sequence up to n terms."""
    a, b = 0, 1
    result = []
    for _ in range(n):
        result.append(a)
        a, b = b, a + b
    return result

def main():
    n = 10
    fib = fibonacci(n)
    print(f"First {n} Fibonacci numbers:")
    print(fib)
    evens = [x for x in fib if x % 2 == 0]
    print(f"Even numbers: {evens}")

if __name__ == "__main__":
    main()`,
    language: "python",
  },
};

const LANG_MAP: Record<string, string> = {
  html: "html", css: "css", js: "javascript", jsx: "javascript",
  ts: "typescript", tsx: "typescript", py: "python", c: "c",
  cpp: "cpp", json: "json", md: "markdown", txt: "plaintext",
};

const LANG_ICONS: Record<string, { icon: string; color: string }> = {
  html:       { icon: "◈", color: "#e34c26" },
  css:        { icon: "◉", color: "#264de4" },
  javascript: { icon: "⬡", color: "#f7df1e" },
  typescript: { icon: "⬡", color: "#3178c6" },
  python:     { icon: "◆", color: "#3776ab" },
  c:          { icon: "◇", color: "#a8b9cc" },
  cpp:        { icon: "◇", color: "#00599c" },
  json:       { icon: "{}", color: "#fbc02d" },
  markdown:   { icon: "M↓", color: "#083fa1" },
  plaintext:  { icon: "∷",  color: "#9e9e9e" },
};

const getLanguage = (filename: string) => {
  const ext = filename.split(".").pop()?.toLowerCase() || "txt";
  return LANG_MAP[ext] || "plaintext";
};

const getLangMeta = (lang: string) => LANG_ICONS[lang] || LANG_ICONS.plaintext;
const getFileIcon = (filename: string) => {
  const lang = getLanguage(filename);
  return getLangMeta(lang);
};

// ─── Monaco Loader Hook ───────────────────────────────────────────────────────
function useMonaco() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    if ((window as any).monaco) { setReady(true); return; }
    const existing = document.querySelector(`script[src="${MONACO_CDN}/loader.js"]`);
    if (existing) {
      const check = setInterval(() => { if ((window as any).monaco) { setReady(true); clearInterval(check); } }, 100);
      return;
    }
    const script = document.createElement("script");
    script.src = `${MONACO_CDN}/loader.js`;
    script.onload = () => {
      (window as any).require.config({ paths: { vs: MONACO_CDN } });
      (window as any).require(["vs/editor/editor.main"], () => setReady(true));
    };
    document.head.appendChild(script);
  }, []);
  return ready;
}

// ─── Monaco Editor ────────────────────────────────────────────────────────────
function MonacoEditorPane({
  content, language, theme, onChange,
}: {
  content: string; language: string; theme: string; onChange?: (v: string) => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const editorRef = useRef<any>(null);
  const modelRef = useRef<any>(null);
  const monacoReady = useMonaco();

  useEffect(() => {
    if (!monacoReady || !containerRef.current) return;
    const monaco = (window as any).monaco;

    monaco.editor.defineTheme("webide-dark", {
      base: "vs-dark", inherit: true,
      rules: [
        { token: "comment", foreground: "6a9955", fontStyle: "italic" },
        { token: "keyword", foreground: "c586c0" },
        { token: "string", foreground: "ce9178" },
        { token: "number", foreground: "b5cea8" },
        { token: "type", foreground: "4ec9b0" },
      ],
      colors: {
        "editor.background": "#0d1117",
        "editor.foreground": "#c9d1d9",
        "editorLineNumber.foreground": "#30363d",
        "editorLineNumber.activeForeground": "#8b949e",
        "editor.selectionBackground": "#264f78",
        "editor.lineHighlightBackground": "#161b22",
        "editorCursor.foreground": "#58a6ff",
        "editorWidget.background": "#161b22",
        "editorSuggestWidget.background": "#161b22",
        "editorSuggestWidget.border": "#30363d",
        "editorSuggestWidget.selectedBackground": "#264f78",
      },
    });

    monaco.editor.defineTheme("webide-light", {
      base: "vs", inherit: true, rules: [],
      colors: {
        "editor.background": "#ffffff",
        "editor.lineHighlightBackground": "#f6f8fa",
        "editorLineNumber.foreground": "#bbb",
        "editorLineNumber.activeForeground": "#555",
      },
    });

    modelRef.current = monaco.editor.createModel(content, language);
    editorRef.current = monaco.editor.create(containerRef.current, {
      model: modelRef.current,
      theme: theme === "dark" ? "webide-dark" : "webide-light",
      fontSize: 14,
      fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
      fontLigatures: true,
      lineNumbers: "on",
      minimap: { enabled: true },
      scrollBeyondLastLine: false,
      automaticLayout: true,
      tabSize: 2,
      wordWrap: "on",
      bracketPairColorization: { enabled: true },
      guides: { bracketPairs: true, indentation: true },
      smoothScrolling: true,
      cursorBlinking: "phase",
      cursorSmoothCaretAnimation: "on",
      quickSuggestions: { other: true, comments: false, strings: false },
      padding: { top: 16, bottom: 16 },
    });

    editorRef.current.onDidChangeModelContent(() => {
      onChange?.(editorRef.current.getValue());
    });

    return () => { editorRef.current?.dispose(); modelRef.current?.dispose(); };
  }, [monacoReady]);

  useEffect(() => {
    if (!editorRef.current) return;
    const cur = editorRef.current.getValue();
    if (cur !== content) {
      const pos = editorRef.current.getPosition();
      editorRef.current.setValue(content);
      if (pos) editorRef.current.setPosition(pos);
    }
  }, [content]);

  useEffect(() => {
    if (!modelRef.current || !(window as any).monaco) return;
    (window as any).monaco.editor.setModelLanguage(modelRef.current, language);
  }, [language]);

  useEffect(() => {
    if (!(window as any).monaco) return;
    (window as any).monaco.editor.setTheme(theme === "dark" ? "webide-dark" : "webide-light");
  }, [theme]);

  if (!monacoReady) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", flexDirection: "column", gap: "12px", background: theme === "dark" ? "#0d1117" : "#fff", color: "#8b949e" }}>
        <div style={{ width: "32px", height: "32px", border: "2px solid #58a6ff", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
        <span style={{ fontSize: "13px" }}>Loading Monaco Editor…</span>
      </div>
    );
  }
  return <div ref={containerRef} style={{ width: "100%", height: "100%" }} />;
}

// ─── Terminal ─────────────────────────────────────────────────────────────────
function TerminalPanel({
  files, onFileChange, theme,
}: {
  files: Record<string, any>;
  onFileChange: (name: string, data: any) => void;
  theme: string;
}) {
  const [history, setHistory] = useState([
    { type: "system", text: "WebIDE Terminal v1.0  —  type 'help' for commands" },
    { type: "system", text: "─".repeat(50) },
  ]);
  const [input, setInput] = useState("");
  const [cmdHistory, setCmdHistory] = useState<string[]>([]);
  const [cmdIdx, setCmdIdx] = useState(-1);
  const [cwd] = useState("/workspace");
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [history]);

  const add = (text: string, type = "output") =>
    setHistory(h => [...h, { type, text }]);

  const CMDS: Record<string, (args: string[]) => void> = {
    help: () => {
      add("Available commands:", "info");
      ["  ls              — list files", "  cat <file>      — show file content",
       "  touch <file>    — create new file", "  echo <text>     — print text",
       "  clear           — clear terminal", "  pwd             — working directory",
       "  node <file.js>  — run JS (sandboxed)", "  date            — current date/time",
       "  whoami          — current user"].forEach(l => add(l));
    },
    ls: () => {
      const keys = Object.keys(files);
      if (!keys.length) { add("(empty)"); return; }
      keys.forEach(f => { const m = getLangMeta(getLanguage(f)); add(`  ${m.icon}  ${f}`, "file"); });
    },
    pwd: () => add(cwd),
    date: () => add(new Date().toString()),
    whoami: () => add("developer@webide"),
    clear: () => setHistory([{ type: "system", text: "Cleared. Type 'help'." }]),
    echo: (a) => add(a.join(" ")),
    cat: (a) => {
      if (!a[0]) { add("Usage: cat <file>", "error"); return; }
      const f = files[a[0]];
      if (!f) { add(`cat: ${a[0]}: No such file`, "error"); return; }
      add(`--- ${a[0]} ---`, "info");
      f.content.split("\n").slice(0, 40).forEach((l: string) => add(l));
      if (f.content.split("\n").length > 40) add("... (truncated)", "info");
    },
    touch: (a) => {
      if (!a[0]) { add("Usage: touch <file>", "error"); return; }
      if (files[a[0]]) { add(`${a[0]} already exists`, "error"); return; }
      onFileChange(a[0], { content: "", language: getLanguage(a[0]) });
      add(`Created: ${a[0]}`, "success");
    },
    node: (a) => {
      if (!a[0]) { add("Usage: node <file.js>", "error"); return; }
      const f = files[a[0]];
      if (!f) { add(`Cannot find '${a[0]}'`, "error"); return; }
      add(`> node ${a[0]}`, "info");
      const logs: string[] = [];
      try {
        const mc = { log: (...x: any[]) => logs.push(x.join(" ")), error: (...x: any[]) => logs.push("Error: " + x.join(" ")), warn: (...x: any[]) => logs.push("⚠ " + x.join(" ")) };
        new Function("console", f.content)(mc);
        logs.forEach(l => add(l, "success"));
        if (!logs.length) add("(no output)", "info");
      } catch (e: any) { add(e.message, "error"); }
    },
  };

  const run = (raw: string) => {
    const t = raw.trim();
    if (!t) return;
    add(`${cwd} $ ${t}`, "prompt");
    setCmdHistory(h => [t, ...h]);
    setCmdIdx(-1);
    const [cmd, ...args] = t.split(/\s+/);
    if (CMDS[cmd]) CMDS[cmd](args);
    else add(`command not found: ${cmd}. Try 'help'.`, "error");
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") { run(input); setInput(""); }
    else if (e.key === "ArrowUp") { const i = Math.min(cmdIdx + 1, cmdHistory.length - 1); setCmdIdx(i); setInput(cmdHistory[i] || ""); }
    else if (e.key === "ArrowDown") { const i = Math.max(cmdIdx - 1, -1); setCmdIdx(i); setInput(i === -1 ? "" : cmdHistory[i]); }
  };

  const tc: Record<string, string> = { system: "#6a9955", info: "#569cd6", error: "#f44747", success: "#4ec9b0", prompt: "#dcdcaa", file: "#9cdcfe", output: "#d4d4d4" };

  return (
    <div style={{ background: "#0d1117", height: "100%", display: "flex", flexDirection: "column", fontFamily: "'JetBrains Mono','Fira Code',monospace", fontSize: "13px" }}>
      <div style={{ flex: 1, overflow: "auto", padding: "12px 16px", cursor: "text" }} onClick={() => inputRef.current?.focus()}>
        {history.map((l, i) => <div key={i} style={{ color: tc[l.type] || tc.output, lineHeight: 1.7, whiteSpace: "pre-wrap", wordBreak: "break-all" }}>{l.text}</div>)}
        <div ref={bottomRef} />
      </div>
      <div style={{ display: "flex", alignItems: "center", padding: "8px 16px", borderTop: "1px solid #21262d", gap: "8px" }}>
        <span style={{ color: "#4ec9b0", fontSize: "12px", whiteSpace: "nowrap" }}>{cwd} $</span>
        <input ref={inputRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey}
          style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "#d4d4d4", fontFamily: "inherit", fontSize: "13px" }}
          autoFocus spellCheck={false} placeholder="type a command…" />
      </div>
    </div>
  );
}

// ─── Live Preview ─────────────────────────────────────────────────────────────
function LivePreview({ files }: { files: Record<string, any> }) {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const html = files["index.html"]?.content || "";
    const css = files["style.css"]?.content || "";
    const js = files["app.js"]?.content || "";
    const combined = html
      .replace("</head>", `<style>${css}</style></head>`)
      .replace("</body>", `<script>${js}<\/script></body>`);
    const doc = iframeRef.current?.contentDocument;
    if (doc) { doc.open(); doc.write(combined); doc.close(); }
  }, [files]);

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <iframe ref={iframeRef} style={{ flex: 1, border: "none", width: "100%", background: "#fff" }} title="preview" sandbox="allow-scripts allow-same-origin" />
    </div>
  );
}

// ─── JS Output Runner ─────────────────────────────────────────────────────────
function JSRunner({ content, theme }: { content: string; theme: string }) {
  const [output, setOutput] = useState<{ type: string; text: string }[]>([]);
  const [ran, setRan] = useState(false);

  const run = () => {
    const logs: { type: string; text: string }[] = [];
    const mc = {
      log: (...a: any[]) => logs.push({ type: "log", text: a.map((x: any) => typeof x === "object" ? JSON.stringify(x, null, 2) : String(x)).join(" ") }),
      error: (...a: any[]) => logs.push({ type: "error", text: "Error: " + a.join(" ") }),
      warn: (...a: any[]) => logs.push({ type: "warn", text: "⚠ " + a.join(" ") }),
      info: (...a: any[]) => logs.push({ type: "info", text: "ℹ " + a.join(" ") }),
    };
    try {
      new Function("console", content)(mc);
      if (!logs.length) logs.push({ type: "info", text: "(script ran with no output)" });
    } catch (e: any) { logs.push({ type: "error", text: e.toString() }); }
    setOutput(logs); setRan(true);
  };

  const tc: Record<string, string> = { log: "#d4d4d4", error: "#f44747", warn: "#dcdcaa", info: "#569cd6" };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#0d1117", fontFamily: "'JetBrains Mono',monospace", fontSize: "13px" }}>
      <div style={{ padding: "8px 14px", background: "#161b22", borderBottom: "1px solid #21262d", display: "flex", gap: "8px", alignItems: "center" }}>
        <button onClick={run} style={{ background: "#238636", border: "none", color: "#fff", padding: "4px 14px", borderRadius: "4px", cursor: "pointer", fontSize: "12px", fontFamily: "inherit" }}>▶ Run</button>
        {ran && <button onClick={() => { setOutput([]); setRan(false); }} style={{ background: "transparent", border: "1px solid #30363d", color: "#8b949e", padding: "4px 10px", borderRadius: "4px", cursor: "pointer", fontSize: "12px" }}>Clear</button>}
        <span style={{ marginLeft: "auto", color: "#8b949e", fontSize: "11px" }}>JavaScript Console</span>
      </div>
      <div style={{ flex: 1, overflow: "auto", padding: "12px 16px" }}>
        {!ran && <div style={{ color: "#444", fontStyle: "italic" }}>Click ▶ Run to execute…</div>}
        {output.map((l, i) => <div key={i} style={{ color: tc[l.type], lineHeight: 1.8, whiteSpace: "pre-wrap", borderBottom: "1px solid #111", paddingBottom: "2px" }}>{l.text}</div>)}
      </div>
    </div>
  );
}

// ─── Main IDE ─────────────────────────────────────────────────────────────────
export default function WebIDE() {
  const [files, setFiles] = useState(DEFAULT_FILES);
  const [openTabs, setOpenTabs] = useState(["index.html", "style.css", "app.js"]);
  const [activeTab, setActiveTab] = useState("index.html");
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [bottomHeight, setBottomHeight] = useState(220);
  const [bottomPanel, setBottomPanel] = useState<"terminal" | "preview" | "output">("terminal");
  const [showBottom, setShowBottom] = useState(true);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [creatingFile, setCreatingFile] = useState(false);
  const [newFileInput, setNewFileInput] = useState("");
  const [saveIndicator, setSaveIndicator] = useState<Record<string, string>>({});
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; file: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const autoSaveTimers = useRef<Record<string, any>>({});

  const isDark = theme === "dark";
  const C = {
    bg: isDark ? "#0d1117" : "#f6f8fa",
    sidebar: isDark ? "#010409" : "#f0f0f0",
    border: isDark ? "#21262d" : "#d0d7de",
    tabBar: isDark ? "#0d1117" : "#f3f3f3",
    tabActive: isDark ? "#161b22" : "#ffffff",
    text: isDark ? "#c9d1d9" : "#24292f",
    muted: isDark ? "#8b949e" : "#57606a",
    accent: "#58a6ff",
    hover: isDark ? "#161b22" : "#e8f0fe",
    active: isDark ? "#161b22" : "#f0f6ff",
    header: isDark ? "#010409" : "#24292f",
    input: isDark ? "#161b22" : "#fff",
    inputBorder: isDark ? "#30363d" : "#d0d7de",
    status: isDark ? "#238636" : "#0969da",
  };

  const handleContentChange = useCallback((filename: string, val: string) => {
    clearTimeout(autoSaveTimers.current[filename]);
    setFiles(p => ({ ...p, [filename]: { ...p[filename], content: val } }));
    setSaveIndicator(p => ({ ...p, [filename]: "saving" }));
    autoSaveTimers.current[filename] = setTimeout(() => {
      setSaveIndicator(p => ({ ...p, [filename]: "saved" }));
      setTimeout(() => setSaveIndicator(p => { const n = { ...p }; delete n[filename]; return n; }), 1500);
    }, 800);
  }, []);

  const openFile = (name: string) => {
    if (!openTabs.includes(name)) setOpenTabs(t => [...t, name]);
    setActiveTab(name);
  };

  const closeTab = (name: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const idx = openTabs.indexOf(name);
    const next = openTabs.filter(t => t !== name);
    setOpenTabs(next);
    if (activeTab === name) setActiveTab(next[Math.max(0, idx - 1)] || next[0] || "");
  };

  const createFile = () => {
    const name = newFileInput.trim();
    if (!name) { setCreatingFile(false); return; }
    if (files[name]) { alert(`'${name}' already exists.`); return; }
    setFiles(p => ({ ...p, [name]: { content: "", language: getLanguage(name) } }));
    setCreatingFile(false); setNewFileInput("");
    openFile(name);
  };

  const deleteFile = (name: string) => {
    if (!confirm(`Delete '${name}'?`)) return;
    setFiles(p => { const n = { ...p }; delete n[name]; return n; });
    setOpenTabs(t => t.filter(x => x !== name));
    if (activeTab === name) setActiveTab(openTabs.filter(x => x !== name)[0] || "");
  };

  const renameFile = (oldName: string, newName: string) => {
    if (!newName || newName === oldName) { setRenaming(null); return; }
    if (files[newName]) { alert("File already exists."); return; }
    setFiles(p => { const n = { ...p }; n[newName] = { ...n[oldName], language: getLanguage(newName) }; delete n[oldName]; return n; });
    setOpenTabs(t => t.map(x => x === oldName ? newName : x));
    if (activeTab === oldName) setActiveTab(newName);
    setRenaming(null);
  };

  const downloadProject = () => {
    const content = Object.entries(files)
      .map(([name, f]) => `// ===== ${name} =====\n${f.content}`)
      .join("\n\n");
    const blob = new Blob([content], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "webide-project.txt";
    a.click();
  };

  const activeFile = files[activeTab];
  const activeLang = activeFile?.language || "plaintext";
  const filtered = searchQuery
    ? Object.keys(files).filter(f => f.toLowerCase().includes(searchQuery.toLowerCase()))
    : Object.keys(files);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: C.bg, color: C.text, fontFamily: "'Segoe UI',system-ui,sans-serif", overflow: "hidden" }}>

      {/* Title Bar */}
      <div style={{ background: C.header, display: "flex", alignItems: "center", padding: "0 14px", height: "38px", borderBottom: `1px solid ${C.border}`, gap: "12px", flexShrink: 0, zIndex: 10 }}>
        <div style={{ display: "flex", gap: "6px" }}>
          {["#ff5f57","#febc2e","#28c840"].map((c,i) => <div key={i} style={{ width: "12px", height: "12px", borderRadius: "50%", background: c }} />)}
        </div>
        <span style={{ flex: 1, textAlign: "center", color: "#8b949e", fontSize: "12px", letterSpacing: "0.06em" }}>
          ⬡ WebIDE {activeTab ? `— ${activeTab}` : ""}
        </span>
        <div style={{ display: "flex", gap: "8px" }}>
          <button onClick={() => setTheme(t => t === "dark" ? "light" : "dark")} style={btnStyle}>{isDark ? "☀ Light" : "🌙 Dark"}</button>
          <button onClick={downloadProject} style={{ ...btnStyle, background: "#238636", color: "#fff", border: "none" }}>↓ Export</button>
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>

        {/* Activity Bar */}
        <div style={{ width: "44px", background: C.header, borderRight: `1px solid ${C.border}`, display: "flex", flexDirection: "column", alignItems: "center", paddingTop: "8px", gap: "2px", flexShrink: 0 }}>
          {([
            ["⊞","Explorer",() => setSidebarOpen(o => !o)],
            ["⊘","Search",() => { setSidebarOpen(true); setShowSearch(s => !s); }],
            ["⊙","Terminal",() => { setShowBottom(true); setBottomPanel("terminal"); }],
            ["◈","Preview",() => { setShowBottom(true); setBottomPanel("preview"); }],
            ["▶","Output",() => { setShowBottom(true); setBottomPanel("output"); }],
          ] as [string,string,()=>void][]).map(([icon,title,action]) => (
            <button key={title} title={title} onClick={action} style={{ width: "36px", height: "36px", background: "transparent", border: "none", color: "#8b949e", cursor: "pointer", borderRadius: "6px", fontSize: "17px", transition: "all 0.15s", display: "flex", alignItems: "center", justifyContent: "center" }}
              onMouseEnter={e => { (e.target as any).style.background = "#21262d"; (e.target as any).style.color = "#c9d1d9"; }}
              onMouseLeave={e => { (e.target as any).style.background = "transparent"; (e.target as any).style.color = "#8b949e"; }}>
              {icon}
            </button>
          ))}
        </div>

        {/* Sidebar */}
        <div style={{ width: sidebarOpen ? "220px" : "0", background: C.sidebar, borderRight: `1px solid ${C.border}`, display: "flex", flexDirection: "column", overflow: "hidden", transition: "width 0.2s", flexShrink: 0 }}>
          <div style={{ padding: "8px 12px 4px", fontSize: "10px", color: C.muted, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", display: "flex", alignItems: "center", justifyContent: "space-between", whiteSpace: "nowrap" }}>
            EXPLORER
            <button onClick={() => setCreatingFile(true)} style={{ background: "transparent", border: "none", color: C.muted, cursor: "pointer", fontSize: "18px", lineHeight: 1, padding: "0 2px" }} title="New File">+</button>
          </div>

          {showSearch && (
            <div style={{ padding: "0 8px 8px" }}>
              <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search files…"
                style={{ width: "100%", background: C.input, border: `1px solid ${C.inputBorder}`, color: C.text, padding: "4px 8px", borderRadius: "4px", fontSize: "12px", outline: "none", boxSizing: "border-box" as const }} />
            </div>
          )}

          <div style={{ flex: 1, overflow: "auto" }}>
            <div style={{ padding: "4px 8px 2px 12px", fontSize: "11px", color: C.muted, fontWeight: 600, whiteSpace: "nowrap" }}>📁 /workspace</div>
            {filtered.map(name => {
              const { icon, color } = getFileIcon(name);
              const isActive = activeTab === name;
              return (
                <div key={name}
                  onContextMenu={e => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY, file: name }); }}
                  onClick={() => openFile(name)}
                  style={{ display: "flex", alignItems: "center", padding: "4px 8px 4px 20px", cursor: "pointer", background: isActive ? C.active : "transparent", borderLeft: isActive ? `2px solid ${C.accent}` : "2px solid transparent", gap: "6px", transition: "background 0.1s", userSelect: "none" }}
                  onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = C.hover; }}
                  onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                  {renaming === name ? (
                    <input autoFocus defaultValue={name}
                      onBlur={e => renameFile(name, (e.target as HTMLInputElement).value)}
                      onKeyDown={e => { if (e.key === "Enter") renameFile(name, (e.target as HTMLInputElement).value); if (e.key === "Escape") setRenaming(null); }}
                      onClick={e => e.stopPropagation()}
                      style={{ background: C.input, border: `1px solid ${C.accent}`, color: C.text, padding: "2px 4px", borderRadius: "3px", fontSize: "12px", outline: "none", width: "100%" }} />
                  ) : (
                    <>
                      <span style={{ color, fontSize: "11px", fontFamily: "monospace", flexShrink: 0 }}>{icon}</span>
                      <span style={{ fontSize: "13px", flex: 1, color: openTabs.includes(name) ? C.text : C.muted, fontWeight: isActive ? 500 : 400, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{name}</span>
                      {saveIndicator[name] && <span style={{ fontSize: "9px", color: saveIndicator[name] === "saved" ? "#3fb950" : "#f7cc45", flexShrink: 0 }}>{saveIndicator[name] === "saved" ? "✓" : "●"}</span>}
                    </>
                  )}
                </div>
              );
            })}
            {creatingFile && (
              <div style={{ padding: "4px 8px 4px 20px" }}>
                <input autoFocus value={newFileInput} onChange={e => setNewFileInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") createFile(); if (e.key === "Escape") { setCreatingFile(false); setNewFileInput(""); } }}
                  onBlur={createFile} placeholder="filename.js"
                  style={{ background: C.input, border: `1px solid ${C.accent}`, color: C.text, padding: "3px 6px", borderRadius: "4px", fontSize: "12px", outline: "none", width: "100%", boxSizing: "border-box" as const }} />
              </div>
            )}
          </div>

          <div style={{ padding: "8px 12px", borderTop: `1px solid ${C.border}`, fontSize: "11px", color: C.muted }}>
            {Object.keys(files).length} file{Object.keys(files).length !== 1 ? "s" : ""}
          </div>
        </div>

        {/* Editor + Bottom */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>

          {/* Tabs */}
          <div style={{ background: C.tabBar, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", overflowX: "auto", flexShrink: 0 }}
            onWheel={e => { (e.currentTarget as HTMLElement).scrollLeft += e.deltaY; }}>
            {openTabs.map(tab => {
              const { icon, color } = getFileIcon(tab);
              const isActive = tab === activeTab;
              return (
                <div key={tab} onClick={() => setActiveTab(tab)}
                  style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 14px", cursor: "pointer", borderRight: `1px solid ${C.border}`, background: isActive ? C.tabActive : "transparent", borderBottom: isActive ? `2px solid ${C.accent}` : "2px solid transparent", minWidth: "110px", maxWidth: "180px", flexShrink: 0, userSelect: "none" }}>
                  <span style={{ color, fontSize: "11px" }}>{icon}</span>
                  <span style={{ fontSize: "12px", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: isActive ? C.text : C.muted }}>
                    {saveIndicator[tab] === "saving" && <span style={{ color: "#f7cc45" }}>● </span>}{tab}
                  </span>
                  <span onClick={e => closeTab(tab, e)} style={{ color: C.muted, fontSize: "15px", lineHeight: 1, cursor: "pointer" }}
                    onMouseEnter={e => { (e.target as any).style.color = "#f44747"; }}
                    onMouseLeave={e => { (e.target as any).style.color = C.muted; }}>×</span>
                </div>
              );
            })}
            {!openTabs.length && (
              <div style={{ padding: "8px 16px", fontSize: "12px", color: C.muted, fontStyle: "italic" }}>Click a file to open it</div>
            )}
          </div>

          {/* Editor */}
          <div style={{ flex: 1, overflow: "hidden", position: "relative" as const }}>
            {activeFile ? (
              <MonacoEditorPane key={activeTab} content={activeFile.content} language={activeFile.language} theme={theme} onChange={v => handleContentChange(activeTab, v)} />
            ) : (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", color: C.muted, gap: "12px" }}>
                <div style={{ fontSize: "52px", opacity: 0.2 }}>⬡</div>
                <div style={{ fontSize: "18px", fontWeight: 600, color: C.text }}>WebIDE</div>
                <div style={{ fontSize: "13px" }}>Open a file from the explorer</div>
                <div style={{ display: "flex", gap: "8px", marginTop: "8px", flexWrap: "wrap" as const, justifyContent: "center" }}>
                  {Object.keys(files).slice(0, 4).map(f => (
                    <button key={f} onClick={() => openFile(f)}
                      style={{ background: C.hover, border: `1px solid ${C.inputBorder}`, color: C.text, padding: "6px 14px", borderRadius: "6px", cursor: "pointer", fontSize: "12px" }}>{f}</button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Bottom Panel */}
          {showBottom && (
            <div style={{ height: `${bottomHeight}px`, borderTop: `1px solid ${C.border}`, display: "flex", flexDirection: "column", flexShrink: 0 }}>
              <div style={{ background: C.tabBar, display: "flex", alignItems: "center", borderBottom: `1px solid ${C.border}`, padding: "0 8px", flexShrink: 0 }}>
                {([["terminal","⊙ TERMINAL"],["preview","◈ PREVIEW"],["output","▶ OUTPUT"]] as [string,string][]).map(([id,label]) => (
                  <button key={id} onClick={() => setBottomPanel(id as any)}
                    style={{ background: "transparent", border: "none", borderBottom: bottomPanel === id ? `2px solid ${C.accent}` : "2px solid transparent", color: bottomPanel === id ? C.text : C.muted, padding: "6px 12px", cursor: "pointer", fontSize: "11px", fontFamily: "inherit", fontWeight: bottomPanel === id ? 600 : 400 }}>
                    {label}
                  </button>
                ))}
                <div style={{ marginLeft: "auto", display: "flex", gap: "4px" }}>
                  <button onClick={() => setBottomHeight(h => Math.max(100, h - 60))} style={iconBtnStyle}>−</button>
                  <button onClick={() => setBottomHeight(h => Math.min(500, h + 60))} style={iconBtnStyle}>+</button>
                  <button onClick={() => setShowBottom(false)} style={iconBtnStyle}>×</button>
                </div>
              </div>
              <div style={{ flex: 1, overflow: "hidden" }}>
                {bottomPanel === "terminal" && <TerminalPanel files={files} onFileChange={(n, d) => setFiles(p => ({ ...p, [n]: d }))} theme={theme} />}
                {bottomPanel === "preview" && <LivePreview files={files} />}
                {bottomPanel === "output" && <JSRunner content={activeFile?.content || ""} theme={theme} />}
              </div>
            </div>
          )}

          {!showBottom && (
            <div style={{ borderTop: `1px solid ${C.border}`, padding: "3px 10px", display: "flex", gap: "6px" }}>
              {([["⊙","terminal"],["◈","preview"],["▶","output"]] as [string,string][]).map(([icon,id]) => (
                <button key={id} onClick={() => { setShowBottom(true); setBottomPanel(id as any); }}
                  style={{ background: "transparent", border: "none", color: C.muted, cursor: "pointer", fontSize: "13px", padding: "2px 6px", borderRadius: "3px" }}>{icon}</button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <div style={{ background: C.status, display: "flex", alignItems: "center", padding: "0 14px", height: "22px", fontSize: "11px", color: "rgba(255,255,255,0.85)", flexShrink: 0, gap: "12px" }}>
        <span>⬡ WebIDE</span>
        <span style={{ opacity: 0.5 }}>|</span>
        <span>{activeLang.toUpperCase()}</span>
        {activeFile && <><span style={{ opacity: 0.5 }}>|</span><span>{activeFile.content.split("\n").length} lines</span></>}
        {saveIndicator[activeTab] && (
          <span style={{ color: saveIndicator[activeTab] === "saved" ? "#7ee787" : "#f7cc45" }}>
            {saveIndicator[activeTab] === "saved" ? "✓ Saved" : "● Saving…"}
          </span>
        )}
        <span style={{ marginLeft: "auto" }}>UTF-8  |  {isDark ? "🌙" : "☀"}  |  Tab: 2</span>
      </div>

      {/* Context Menu */}
      {contextMenu && (
        <>
          <div onClick={() => setContextMenu(null)} style={{ position: "fixed", inset: 0, zIndex: 998 }} />
          <div style={{ position: "fixed", left: contextMenu.x, top: contextMenu.y, background: isDark ? "#161b22" : "#fff", border: `1px solid ${C.inputBorder}`, borderRadius: "6px", zIndex: 999, boxShadow: "0 8px 24px rgba(0,0,0,0.4)", overflow: "hidden", minWidth: "160px" }}>
            {[
              { label: "Open", action: () => { openFile(contextMenu.file); setContextMenu(null); } },
              { label: "Rename", action: () => { setRenaming(contextMenu.file); setContextMenu(null); } },
              { label: "Delete", action: () => { deleteFile(contextMenu.file); setContextMenu(null); }, danger: true },
            ].map(({ label, action, danger }) => (
              <div key={label} onClick={action} style={{ padding: "8px 14px", cursor: "pointer", fontSize: "13px", color: danger ? "#f44747" : C.text }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = C.hover; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                {label}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

const btnStyle: React.CSSProperties = {
  background: "transparent", border: "1px solid #30363d", color: "#8b949e",
  padding: "3px 10px", borderRadius: "4px", cursor: "pointer", fontSize: "11px", fontFamily: "inherit",
};

const iconBtnStyle: React.CSSProperties = {
  background: "transparent", border: "none", color: "#8b949e",
  cursor: "pointer", fontSize: "16px", padding: "0 4px", fontFamily: "inherit",
};
