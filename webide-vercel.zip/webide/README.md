# ⬡ WebIDE

A full VS Code-style IDE that runs in the browser — built with Next.js + Monaco Editor.

## Features

- 🗂 File explorer (create, rename, delete — right-click menu)
- ✏️ Monaco Editor (same engine as VS Code) with syntax highlighting
- 🔵 Multi-tab editing
- 💾 Auto-save with visual indicator
- 🌙 Dark / Light mode
- ⊙ Integrated terminal (ls, cat, touch, node, echo, pwd, date...)
- ◈ Live HTML/CSS/JS preview
- ▶ JavaScript output runner
- ↓ Export project

## Local Development

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy to Vercel

### Option 1 — Vercel CLI (fastest)

```bash
npm install -g vercel
vercel
```

Follow the prompts. Done ✅

### Option 2 — GitHub + Vercel Dashboard

1. Push this repo to GitHub
2. Go to https://vercel.com/new
3. Import your GitHub repo
4. Click Deploy — no config needed

### Option 3 — Drag & Drop

```bash
npm run build
```

Then drag the `.next` folder to https://vercel.com/new

## Project Structure

```
webide/
├── src/
│   ├── app/
│   │   ├── layout.tsx      # Root layout
│   │   ├── page.tsx        # Home page
│   │   └── globals.css     # Global styles
│   └── components/
│       └── WebIDE.tsx      # Full IDE component
├── next.config.js
├── vercel.json
└── package.json
```
