import WebIDE from "@/components/WebIDE";

export default function Home() {
  return <WebIDE />;
}
