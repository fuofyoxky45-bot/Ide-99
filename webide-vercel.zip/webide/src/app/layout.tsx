import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "WebIDE — VS Code in your browser",
  description: "A full-featured web IDE with Monaco Editor, terminal, and live preview",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>⬡</text></svg>" />
      </head>
      <body style={{ margin: 0, padding: 0, overflow: "hidden" }}>{children}</body>
    </html>
  );
}
